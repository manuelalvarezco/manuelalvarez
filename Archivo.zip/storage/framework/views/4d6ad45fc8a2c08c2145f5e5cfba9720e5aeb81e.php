<?php $__env->startSection('title', 'About'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="container">
        <div class="image-bg"
        ></div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/luismanuelalvarez/Documents/Laravel/manuelalvarez/resources/views/pages/contact.blade.php ENDPATH**/ ?>