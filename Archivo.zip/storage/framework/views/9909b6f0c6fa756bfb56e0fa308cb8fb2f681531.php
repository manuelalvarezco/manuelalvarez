<?php $__env->startSection('title', 'Posts' ); ?>
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8 col-xs-12">
            <div>
                <?php if($post->image): ?>
                        <img src="<?php echo e($post->get_image); ?>" class="card-img-top">
                    <?php endif; ?>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($post->iframe): ?>
                        <div class="embed-responsive embed-responsive-16by9">
                        <?php echo $post->iframe; ?>

                        </div>
                    <?php endif; ?>
                    <h5 class="card-title"><?php echo e($post->title); ?></h5>
                    <p class="card-text">
                        <?php echo e($post->body); ?>

                    </p>
                    <p class="text-muted mb-0">
                        <em>
                            &ndash; <?php echo e($post->user->name); ?>

                        </em>
                        <?php echo e($post->created_at->format('d M Y')); ?>

                    </p>
                    <buttons-component id="<?php echo e($post->id); ?>" likes="<?php echo e($post->likes); ?>" hearts="<?php echo e($post->hearts); ?>" ></buttons-component>
                    <?php if($post->comment): ?>
                    <div class="container">
                        <div class="row justify-content-between align-items-center">
                            <small>Comentarios</small>
                        </div>
                        <div class="comments-box d-flex flex-column mt-2">
                            <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="comments-item d-flex flex-column">
                                <p class="text-muted ">
                                    <?php echo e($value->body); ?>

                                </p>

                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>

                    <form action="<?php echo e(route('comments.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="body">Comentar</label>
                            <textarea required maxlength="100" class="form-control" id="body" name="body" rows="2"></textarea>
                        </div>
                        <input type="hidden" value="<?php echo e($post->id); ?>" name="post_id">
                        <div class="d-flex justify-content-end">
                            <input type="submit" value="Enviar" class="btn btn-sm btn-primary">
                        </div>
                    </form>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/luismanuelalvarez/Documents/Laravel/manuelalvarez/resources/views/pages/post.blade.php ENDPATH**/ ?>