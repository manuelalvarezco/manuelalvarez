<?php $__env->startSection('title', 'Contacto'); ?>


<?php $__env->startSection('content'); ?>

<div class="container mt-4" >
    <div class="row">
        <div class="col-md-6 text-center">
            <img style="max-width: 100%" src="<?php echo e(url('/img/producto.png')); ?>" alt="producto">
          </div>
      <div class="col-md-6 d-flex justify-content-center align-items-center flex-column">
          <h2 class="titulo text-dark text-uppercase">Contáctanos</h2>
        <contact-form-component></contact-form-component>
      </div>

    </div>



      </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.modifyApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/luismanuelalvarez/Documents/Laravel/manuelalvarez/resources/views/contact.blade.php ENDPATH**/ ?>