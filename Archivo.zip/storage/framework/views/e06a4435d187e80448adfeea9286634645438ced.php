<footer-component></footer-component>
<?php /**PATH /Users/luismanuelalvarez/Documents/Laravel/manuelalvarez/resources/views/partials/footer.blade.php ENDPATH**/ ?>