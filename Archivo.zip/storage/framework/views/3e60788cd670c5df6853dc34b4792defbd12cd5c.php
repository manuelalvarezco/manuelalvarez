<?php $__env->startSection('title', 'FAQS'); ?>


<?php $__env->startSection('content'); ?>
<div class="container">

    <faqs-component></faqs-component>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.modifyApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/luismanuelalvarez/Documents/Laravel/manuelalvarez/resources/views/faqs.blade.php ENDPATH**/ ?>