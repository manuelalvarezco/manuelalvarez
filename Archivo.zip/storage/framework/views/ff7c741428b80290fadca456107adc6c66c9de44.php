<?php $__env->startSection('title', 'Inicio'); ?>


<?php $__env->startSection('content'); ?>
    <main-component></main-component>
    <contact-component></contact-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/luismanuelalvarez/Documents/Laravel/manuelalvarez/resources/views/pages/welcome.blade.php ENDPATH**/ ?>