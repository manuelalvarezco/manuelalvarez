
<toolbar-component></toolbar-component>
<?php /**PATH /Users/luismanuelalvarez/Documents/Laravel/manuelalvarez/resources/views/partials/navbar.blade.php ENDPATH**/ ?>