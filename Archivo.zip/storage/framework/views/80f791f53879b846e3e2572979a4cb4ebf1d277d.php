<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


    <title>Manuel Alvarez - <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app">
            <toolbar-dashboard-component></toolbar-dashboard-component>
           <main class="container">
               <?php echo $__env->yieldContent('content'); ?>
           </main>
    </div>
</body>
</html>
<?php /**PATH /Users/luismanuelalvarez/Documents/Laravel/manuelalvarez/resources/views/layouts/dashboard.blade.php ENDPATH**/ ?>