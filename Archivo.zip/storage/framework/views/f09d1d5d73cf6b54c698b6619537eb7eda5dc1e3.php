<?php $__env->startSection('title', 'Posts'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-end">
        <div class="col-md-10">
            <h2>Customers</h2>
            <div class="row">

                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($customer->name); ?></h5>
                            <span class="card-subtitle"><?php echo e($customer->email); ?></span>
                            <p class="card-text"><?php echo e($customer->message); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/luismanuelalvarez/Documents/Laravel/manuelalvarez/resources/views/customers/index.blade.php ENDPATH**/ ?>