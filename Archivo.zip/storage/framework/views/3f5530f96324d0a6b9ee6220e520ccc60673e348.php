
    <div class="jumbotron">
        <h1 class="display-4"><?php echo e($title); ?></h1>
        <p class="lead">Tienes un nuevo mensaje</p>
        <hr class="my-4">
        <p>Alguien te ha enviado un mensaje desde la página!!</p>
        <a class="btn btn-primary btn-lg" href="#" role="button">Revisar</a>
      </div>

<?php /**PATH /Users/luismanuelalvarez/Documents/Laravel/manuelalvarez/resources/views/emails/message.blade.php ENDPATH**/ ?>