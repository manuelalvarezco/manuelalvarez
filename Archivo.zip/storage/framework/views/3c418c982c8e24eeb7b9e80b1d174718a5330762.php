<?php $__env->startSection('title', 'Posts'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-end">
        <div class="col-md-10">
            <div class="d-flex justify-content-end">
                <a href="<?php echo e(route('services.create')); ?>" class="btn btn-sm btn-primary btn-create">Crear</a>
            </div>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="container">
                        <div class="row">
                            <div class="card-columns">
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card">
                                  <div class="card-body">
                                    <?php if($service->image): ?>
                                    <img src="<?php echo e($service->get_image); ?>" class="card-img-top">
                                    <?php endif; ?>
                                    <h5 class="card-title mt-2"><?php echo e($service->title); ?></h5>
                                    <div class="d-flex justify-content-between">
                                        <a class="btn btn-outline-success" href="<?php echo e(route('services.edit', $service)); ?>"  class="btn btn-sm btn-success">Editar</a>
                                        <form action="<?php echo e(route('services.destroy', $service)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-outline-danger" onclick="return confirm('¿Are you Sure?')">Eliminar</button>
                                        </form>
                                    </div>
                                  </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                        </div>
                    </div>
                    <?php echo e($services->links()); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/luismanuelalvarez/Documents/Laravel/manuelalvarez/resources/views/services/index.blade.php ENDPATH**/ ?>