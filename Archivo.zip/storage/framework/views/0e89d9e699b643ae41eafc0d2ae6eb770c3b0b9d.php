<?php $__env->startSection('title', 'Services'); ?>
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="container">
        <div class="image-bg"
        ></div>

    </div>
    <div class="col-md-8">

        <services-component></services-component>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/luismanuelalvarez/Documents/Laravel/manuelalvarez/resources/views/pages/services.blade.php ENDPATH**/ ?>