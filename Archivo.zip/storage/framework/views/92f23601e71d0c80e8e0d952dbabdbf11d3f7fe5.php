<?php $__env->startSection('title', 'Projects' ); ?>
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8 col-xs-12">
            <div>
                <?php if($project->image): ?>
                        <img src="<?php echo e($project->get_image); ?>" class="card-img-top">
                    <?php endif; ?>
                <div class="card-body">
                    <?php if($project->iframe): ?>
                        <div class="embed-responsive embed-responsive-16by9">
                        <?php echo $project->iframe; ?>

                        </div>
                    <?php endif; ?>
                    <h5 class="card-title"><?php echo e($project->title); ?></h5>
                    <p class="card-text">
                        <?php echo e($project->body); ?>

                    </p>
                    <div class="d-flex align-items-center justify-content-lg-between flex-wrap">

                        <p class="text-muted mb-0">
                            <em>
                                &ndash; Realizado con <?php echo e($project->tecnology); ?>

                            </em>
                        </p>
                        <small>URL: <a href="<?php echo e($project->url); ?>"><?php echo e($project->title); ?></a></small>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/luismanuelalvarez/Documents/Laravel/manuelalvarez/resources/views/pages/project.blade.php ENDPATH**/ ?>