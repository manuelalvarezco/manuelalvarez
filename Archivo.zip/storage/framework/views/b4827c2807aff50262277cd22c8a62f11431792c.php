<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($project->title); ?></h5>
                    <p class="card-text">
                        <?php echo e($project->get_excerpt); ?>

                        <a href="<?php echo e(route('project', $project)); ?>">Leer Más</a>
                    </p>
                    <p class="text-muted mb-0">
                        <em>
                            &ndash; <?php echo e($project->user->name); ?>

                        </em>
                        <?php echo e($project->created_at->format('d M Y')); ?>

                    </p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($projects->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/luismanuelalvarez/Documents/Laravel/manuelalvarez/resources/views/pages/projects.blade.php ENDPATH**/ ?>