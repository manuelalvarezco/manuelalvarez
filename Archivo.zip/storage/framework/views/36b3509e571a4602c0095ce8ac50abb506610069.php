<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="icon" type="image/png" href="<?php echo e(url('/img/bio-ico.png')); ?>">
    <title>Biowell - <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">


          <a class="navbar-brand d-flex align-items-center" href="/">
              <img src="<?php echo e(url('img/icono-blanco.png')); ?>" width="80" alt="logo">
              <h2 class="mt-3 titulo" style="color:white;">Biowell</h2>
            </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item active">
                <a class="nav-link titulo" href="<?php echo e(url('/')); ?>">INICIO <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link titulo" href="<?php echo e(url('/faqs')); ?>">FAQS</a>
              </li>
              <li class="nav-item">
                  <a class="nav-link titulo" href="<?php echo e(url('/contact')); ?>">CONTACTO</a>
                </li>
            </ul>
          </div>
      </div>
        </nav>

    <div id="app">
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
</html>
<?php /**PATH /Users/luismanuelalvarez/Documents/Laravel/manuelalvarez/resources/views/layouts/modifyApp.blade.php ENDPATH**/ ?>