<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit Project</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form
                        action="<?php echo e(route('projects.update', $project)); ?>"
                        method="POST"
                        enctype="multipart/form-data"
                        >

                        <div class="form-group">
                            <label for="title">Título *</label>
                            <input type="text" name="title" class="form-control" id="title" required value="<?php echo e(old('title', $project->title)); ?>">
                        </div>
                        <div class="form-group">
                            <label for="tecnology">Tecnology</label>
                            <select class="form-control" id="tecnology" name="tecnology" value="<?php echo e(old('tecnology', $project->tecnology)); ?>">
                              <option value="Angular">Angular</option>
                              <option value="Laravel">Laravel</option>
                              <option value="Vue">Vue</option>
                            </select>
                          </div>
                        <div class="form-group">
                            <label for="file">Imagen</label>
                            <input type="file" name="file" id="file" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="url">URL</label>
                            <input type="text" name="url" id="url" class="form-control" value="<?php echo e(old('url', $project->url)); ?>">
                        </div>

                        <div class="form-group">
                            <label for="body">Contenido *</label>
                            <textarea name="body" id="body" rows="6" class="form-control" required><?php echo e(old('body', $project->body)); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="iframe">Contenido embebido</label>
                            <textarea name="iframe" id="iframe" class="form-control"><?php echo e(old('iframe', $project->iframe)); ?></textarea>
                        </div>
                        <div class="form-group">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="submit" value="Actualizar" class="btn btn-primary">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/luismanuelalvarez/Documents/Laravel/manuelalvarez/resources/views/projects/edit.blade.php ENDPATH**/ ?>