@extends('layouts.dashboard')
@section('title', 'Home')

@section('content')

@endsection
