@extends('layouts.app')
@section('title', 'About')
@section('content')
<div class="container">
    <div class="container">
        <div class="image-bg"
        ></div>

    </div>
</div>
@endsection
