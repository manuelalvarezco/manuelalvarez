@extends('layouts.app')

@section('title', 'Inicio')


@section('content')
    <main-component></main-component>
    <contact-component></contact-component>
@endsection
