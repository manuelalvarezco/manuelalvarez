@extends('layouts.app')

@section('title', 'Inicio')


@section('content')
    <main-component></main-component>
@endsection
