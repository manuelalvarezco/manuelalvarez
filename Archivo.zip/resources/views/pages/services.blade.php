@extends('layouts.app')
@section('title', 'Services')
@section('content')
<div class="row justify-content-center">
    <div class="container">
        <div class="image-bg"
        ></div>

    </div>
    <div class="col-md-8">

        <services-component></services-component>
    </div>
</div>
@endsection
