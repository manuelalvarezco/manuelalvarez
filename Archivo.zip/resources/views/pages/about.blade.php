@extends('layouts.app')
@section('title', 'About')
@section('content')
<div class="container">
    <div class="container">
        <div class="image-bg"
        ></div>

    </div>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <cetificates-component></cetificates-component>
        </div>
    </div>
</div>
@endsection
