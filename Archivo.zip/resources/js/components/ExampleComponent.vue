<template>
    <div>
        <h2>Example Component</h2>
    </div>
</template>
<script>
export default {
}
</script>
